<?
$site_path = "http://path_to_website/";
$site_imgpath = "http://path_to_website/images";
$img_fullpath = "/full_path/to/images/dir/";




$img_num_in_line = 3;
$img_num_on_page = 12;
$footer_width = 300;

$cellprop = array(
			"bgcolor" => "#E3E3E3",
			"border" => 1, 
			"bordercolor" => "orange", 
			"padding" => 10, 
			"spacing" => 5
		);


$my_user = "mygallery";
$my_passw = "administrator";


$all_types = array(
	"image/jpeg",
	"image/pjpeg",
	"image/gif",
	"image/png"
);

$linkclass = "link";
$link = $site_path."?";
?>