This directory contains extra packages that SPGM uses.

- Overlib
This javascript library is used to display EXIF data. This is a modified 
version from the original that can be found at
http://www.bosrup.com/web/overlib/
For license and copyright information, refer to overlib410/License.txt 
