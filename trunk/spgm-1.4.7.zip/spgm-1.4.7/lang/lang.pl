<?php

# link to SPGM
$spgm_cfg['locale']['spgmLink'] = 'galeria wygenerowana przez >SPGM_LINK<';

# thumbnails navi bar
$spgm_cfg['locale']['thumbnailNaviBar']  = 'strona >CURRENT_PAGE< z >NB_PAGES<';

# filter label
$spgm_cfg['locale']['filter'] = 'filtr';

# filter value for 'new pictures'
$spgm_cfg['locale']['filterNew'] = 'nowe zdj�cia';

# filter value for 'all pictures'
$spgm_cfg['locale']['filterAll'] = 'wszystkie zdj�cia';

# filter value for 'slideshow'
$spgm_cfg['locale']['filterSlideshow'] = 'Slideshow';

# pictures navi bar
$spgm_cfg['locale']['pictureNaviBar'] = 'zdj�cie >CURRENT_PIC< z >NB_PICS<';

# picture label (as in '1 picture')
$spgm_cfg['locale']['picture'] = 'zdj�cie';

# pictures label (as in '2 pictures')
$spgm_cfg['locale']['pictures'] = 'zdj�cia';

# new picture label (as in '1 new picture')
$spgm_cfg['locale']['newPicture'] = 'nowe zdj�cie';

# new pictures label (as in '2 new pictures')
$spgm_cfg['locale']['newPictures'] = 'nowe zdj�cia';

# new gallery label
$spgm_cfg['locale']['newGallery'] = 'nowa galeria';

# main gallery label
$spgm_cfg['locale']['rootGallery'] = 'galeria g��wna';

?>
